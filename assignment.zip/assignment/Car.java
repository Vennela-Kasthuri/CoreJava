package day002;

	public class Car extends Vehicle {

		String airbag;
		@Override
		public void showDetails() {
			// TODO Auto-generated method stub

		}

		public void xyz() {
			abc();
			System.out.println();
			System.out.println();
			System.out.println();
		}
	}

