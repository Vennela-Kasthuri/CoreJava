package day002;

public class Team {
		
		String name;
		String player;

		public Team(String name, String player) {
			
			this.name = name;
			this.player = player;
		}
	public Team() {
			// TODO Auto-generated constructor stub
		}
	public String getName() {
			
			return name;
		}
	public void setName(String team, String name) {
		this.name = name;
	}
	public String getPlayer() {
		
		return player;
	}
	public void setPlayer(String player) {
		this.player = player;
		
	}
	public void setName(String team) {
		// TODO Auto-generated method stub
		
	}

	}


		





