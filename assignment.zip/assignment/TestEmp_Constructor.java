import java.util.Scanner;

public class TestEmp_Constructor {

	public static void main(String[] args) {

		CoreJavaEmployee e[]=new CoreJavaEmployee[80];
		Scanner s=new Scanner(System.in);
		//constructor
		for (int i = 0; i < e.length; i++) {
			System.out.println("Enter the emp id:");
			int id=s.nextInt();
			System.out.println("Enter the emp name:");
			String name=s.next();
			System.out.println("Enter the batch:");
			int bt=s.nextInt();
			e[i]=new CoreJavaEmployee(id, name, bt);
		}
		for (int i = 0; i < e.length; i++) {
			System.out.println(e[i].getEmpId());
			System.out.println(e[i].getEmpName());
			System.out.println(e[i].getBatch());
		}
	}
}
