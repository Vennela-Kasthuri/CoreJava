package day002;

	import java.util.*;
	public class Demo {
		public static void main(String[] args) {
				
				Scanner sc = new Scanner(System.in);
				System.out.print("Enter Number of Students : ");
				int n = sc.nextInt();
				sc.nextLine();
				
				Player[] p1 = new Player[n];
				for(int i=0;i<n;i++) {
					System.out.println("Enter Student "+(i+1) +" Detail");
					Player player = new Player();
					String PlayerName,PlayerCountry,PlayerSkill;
					System.out.println("Enter Player Name : ");
					PlayerName=sc.nextLine();
					System.out.println("Enter Country Name : ");
					PlayerCountry=sc.nextLine();
					System.out.println("Enter Skill : ");
					PlayerSkill=sc.nextLine();
					Skill skill = new Skill();
					skill.setSkillName(PlayerSkill);
					player.setCountry(PlayerCountry);
					player.setName(PlayerName);
					player.setSkill(skill);
					p1[i]=player;
				}
				Player studentDetails = new Player();
				boolean run = true;
				while(run) {
					System.out.println("Menu : \n1.View Details\n2.Filter Students with Skills\n3.Exit");
					int choice = sc.nextInt();
					sc.nextLine();
					switch(choice) {
					case 1:
						studentDetails.Details(p1);
						break;
					case 2:
						String skillValue = sc.nextLine();
						studentDetails.printStudentDetailsWithSkill(p1, skillValue);
						break;
					case 3:
						run = false;
					}
				}
				sc.close();
		}
	}

