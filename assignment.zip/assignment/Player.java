package day002;

	public class Player {
		private String name;
		private String country;
		private Skill skill;
			
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}
		
		public Skill getSkill() {
			return skill;
		}

		public void setSkill1(Skill skill) {
			this.skill = skill;
		}

		@Override
		public String toString() {
			return String.format("%-15s %-15s %-15s",name,country,skill.toString());
		}

		public void setSkill11(Skill skill2) {
			// TODO Auto-generated method stub
			
		}

		public void setSkill(Skill skill2) {
			// TODO Auto-generated method stub
			
		}

		public void setCountry1(String playerCountry) {
			// TODO Auto-generated method stub
			
		}

		public void setName1(String playerName) {
			// TODO Auto-generated method stub
			
		}

		public void printStudentDetailsWithSkill(Player[] p1, String skillValue) {
			// TODO Auto-generated method stub
			
		}

		public void Details(Player[] p1) {
			// TODO Auto-generated method stub
			
		}
	}



