package day002;

	public class PlayerBO {
		public void Details(Player[] playerList) {
			System.out.println("Player\t\tCountry\t\tSkill");
			for(Player p1:playerList) {
				System.out.println(p1);
			}
		}
		
		public void printStudentDetailsWithSkill(Player[] playerList,String skill) {
			boolean studentFound=false;
			for(Player p1:playerList) {
				if(p1.getSkill().getSkillName().equals(skill)) {
					System.out.println(p1);
					studentFound=true;
				}
			}
			if(!studentFound) {
				System.out.println("Skill Not Found");
			}
		}
	}



