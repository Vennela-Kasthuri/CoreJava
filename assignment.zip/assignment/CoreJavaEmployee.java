import java.util.*;
		public class CoreJavaEmployee {

			//4 attributes/instance members//non-static data members
			private long empId; //100
			private String empName; //50
			private int batch;//4
			
			//
			static {
				System.out.println("in static block.....");
				batch_size=10;
			}
			//class members
			private static int batch_size;

			//default construe
			public CoreJavaEmployee() {
				System.out.println(" I am default constr...");
			}
			//non-static methods can access static and non-static data members 
			//para constructor 
			//(20,"Ram","Batch2")
			public CoreJavaEmployee(int eid, String eName, int batchname) {
				batch_size++;
				System.out.println(" I am para constr...");
				this.empId = eid;
				this.empName = eName;
				this.batch = batchname;
			}

			public long getEmpId() {
				return empId;
			}

			public void setEmpId(long empId) {
				this.empId = empId;
			}
			public String getEmpName() {
				return empName;
			}
			public void setEmpName(String empName) {
				this.empName = empName;
			}
			public int getBatch() {
				return this.batch;
			}
			public void setBatch(int batch) {
				this.batch = batch;
			}
			
			//static methods cant access non-static data members 
			//static methods can ONLY access static data members 
			//class method
			public static void showBatchsize() {
				System.out.println(batch_size);
			}
		
	}


