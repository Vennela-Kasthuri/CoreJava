package myAssignment;

public class MoneyManagement {
	private double nec;
	private double ffa;
	private double edu;
	private double ltss;
	private double play;
	private double give;
	
	public double getNec() {
		return nec;
	}
	public void setNec(double nec) {
		this.nec=nec;
	}
	public double getFfa() {
		return ffa;
	}
	public void setFfa(double ffa) {
		this.ffa = ffa;
	}
	public double getEdu() {
		return edu;
	}
	public void setEdu(double edu) {
		this.edu = edu;
	}
	public double getLtss() {
		return ltss;
	}
	public void setLtss(double ltss) {
		this.ltss = ltss;
	}
	public double getPlay() {
		return play;
	}
	public void setPlay(double play) {
		this.play = play;
	}
	public double getGive() {
		return give;
	}
	public void setGive(double give) {
		this.give = give;
	}

}
