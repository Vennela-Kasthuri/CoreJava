package day002;

import java.util.Scanner;

public class Customer implements MyInterface{

	private int custId;
	private long custMob;
	
	public void acceptData() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the cust id:");
		this.custId=s.nextInt();
		System.out.println("Enter the cust mobile:");
		this.custMob=s.nextLong();
	}
	
	public void showData() {
		System.out.println(custId);
		System.out.println(custMob);
	}
	
	
}

