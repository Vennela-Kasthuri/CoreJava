package day002;

public class SchoolApp {

	public static void main(String[] args) {
		
		Student s1=new Student();
		s1.setName("Hyma");
		s1.setRollno(34);
		System.out.println(s1.getName()+" "+s1.getRollno());
		
		Student s2=new Student("Reshma",23);
		System.out.println(s2.getName()+" "+s2.getRollno());
	}
}

}
