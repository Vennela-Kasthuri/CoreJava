package day002;

public abstract class Vehicle {

	String wheels, price, gears;
	public abstract void showDetails();
	
	//54 public methods
	public void abc(){
		//54 lines of code 
	}
}

