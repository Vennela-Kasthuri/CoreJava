package day002;

public class delivaryBo {
	    public static void main(String[] args)
	    {
	        Inningdelivery inningdelivery = new Inningdelivery();
	        inningdelivery.inning();
		inningdelivery.delivery();
		inningdelivery.result();
	    }
	}


