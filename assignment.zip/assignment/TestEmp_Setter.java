import java.util.Scanner;

	public class TestEmp_Setter {

		public static void main(String[] args) {

			//int myarray[]=new int[7];
			//array of objects
			CoreJavaEmployee e[]=new CoreJavaEmployee[2];
			//System.in==keyboard
			//System.out==console
			Scanner s=new Scanner(System.in);
			//setter
			for (int i = 0; i < e.length; i++) {
				e[i]=new CoreJavaEmployee();
				System.out.println("Enter the emp id:");
				int id=s.nextInt();
				e[i].setEmpId(id);
				System.out.println("Enter the emp name:");
				String name=s.next();
				e[i].setEmpName(name);
				System.out.println("Enter the batch:");
				int bt=s.nextInt();
				e[i].setBatch(bt);
			}
			
			for (int i = 0; i < e.length; i++) {
				System.out.println(e[i].getEmpId());
				System.out.println(e[i].getEmpName());
				System.out.println(e[i].getBatch());
			}

		}
	}
